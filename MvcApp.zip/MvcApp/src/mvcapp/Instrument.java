
package mvcapp;

public class Instrument {
    
}
