
package mvcapp;

public class MvcApp {

    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
    
}
